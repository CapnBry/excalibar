1. Check the install.txt file (from sourceforge's excalibar cvs) for system requirements to run Cheyenne.

2. You can get GLUT for Win32 here: http://www.xmission.com/~nate/glut.html

3. Play with the options! There are quite a few under Display->Configure Display.